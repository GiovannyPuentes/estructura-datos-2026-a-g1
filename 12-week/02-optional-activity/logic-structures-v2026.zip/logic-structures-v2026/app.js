const topics = [
  {
    id: "arrays",
    short: "A1",
    title: "Arrays",
    summary: "Gestión contigua de datos para lectura rápida, control de índices y operaciones de acceso determinísticas.",
    focus: ["Acceso O(1)", "Memoria contigua", "Indexación estable"],
    specs: [
      ["Insert at end", "O(1) amort.", "O(1)", "Escala bien cuando existe capacidad reservada."],
      ["Insert at position", "O(n)", "O(1)", "Desplazamiento secuencial de elementos."],
      ["Search by value", "O(n)", "O(1)", "Recorrido lineal sobre el bloque contiguo."],
      ["Delete by index", "O(n)", "O(1)", "El resto de posiciones se reacomoda."],
    ],
    memory:
      "Un array mantiene una región contigua en heap. El acceso al índice es directo por aritmética de dirección, por eso la lectura es constante. Cuando el tamaño crece, la estructura puede requerir una nueva asignación y copia del bloque, lo que explica el costo amortizado en inserción al final.",
    code: `package com.logicstructures.arrays;

import org.springframework.stereotype.Service;

/**
 * Servicio de dominio para ejecutar operaciones sobre un arreglo de enteros.
 * El objetivo es exponer una API simple, predecible y fácil de auditar.
 */
@Service
public class ArrayAnalyticsService {

    /**
     * Calcula el promedio de los valores recibidos.
     *
     * @param values arreglo de entrada
     * @return promedio matemático
     */
    public double average(int[] values) {
        if (values == null || values.length == 0) {
            throw new IllegalArgumentException("The array cannot be empty");
        }

        int sum = 0;
        for (int value : values) {
            sum += value;
        }
        return (double) sum / values.length;
    }

    /**
     * Localiza un valor y devuelve su posición.
     *
     * @param values arreglo a inspeccionar
     * @param target valor objetivo
     * @return índice encontrado o -1
     */
    public int indexOf(int[] values, int target) {
        for (int i = 0; i < values.length; i++) {
            if (values[i] == target) {
                return i;
            }
        }
        return -1;
    }
}` ,
    challenges: [
      { id: "A1", title: "Normalización de inventario", chip: "Array", input: "Recibe una lista de cantidades por SKU.", process: "Recorre el arreglo y calcula el total operativo.", output: "Devuelve el acumulado listo para consolidación." },
      { id: "A2", title: "Filtro de picos de consumo", chip: "Array", input: "Ingresa lecturas de un turno.", process: "Inspecciona cada posición para detectar máximos.", output: "Entrega el índice del pico más alto." },
      { id: "A3", title: "Rotación de prioridades", chip: "Array", input: "Captura un bloque ordenado de prioridades.", process: "Desplaza los elementos una posición.", output: "Publica la nueva secuencia priorizada." },
      { id: "A4", title: "Validación de métricas", chip: "Array", input: "Recibe valores operativos diarios.", process: "Compara cada valor contra un umbral.", output: "Marca los registros que exceden el límite." },
      { id: "A5", title: "Consolidación de lotes", chip: "Array", input: "Entra un lote de datos numéricos.", process: "Suma y promedia cada registro.", output: "Entrega el resumen estadístico." },
    ],
  },
  {
    id: "matrices",
    short: "M1",
    title: "Matrices",
    summary: "Estructura bidimensional para modelar tableros, mapas de calor, inventarios por celda y cálculos cruzados.",
    focus: ["Fila/columna", "Mapeo bidimensional", "Procesamiento intensivo"],
    specs: [
      ["Access cell", "O(1)", "O(1)", "El índice compuesto resuelve una posición exacta."],
      ["Traverse rows", "O(r × c)", "O(1)", "Recorrido completo de toda la superficie de datos."],
      ["Insert row", "O(r × c)", "O(r × c)", "Puede requerir reconstrucción de la grilla."],
      ["Search value", "O(r × c)", "O(1)", "Exploración secuencial por filas o columnas."],
    ],
    memory:
      "Una matriz en JVM se materializa como arreglo de arreglos o como bloque lineal indexado. En ambos casos reside en heap, con punteros o cálculos de offset para ubicar cada celda. La localidad espacial mejora el rendimiento en recorridos secuenciales, especialmente cuando la iteración respeta el orden de almacenamiento.",
    code: `package com.logicstructures.matrices;

import org.springframework.stereotype.Service;

/**
 * Servicio para análisis y operación de grillas bidimensionales.
 */
@Service
public class MatrixOperationsService {

    /**
     * Suma todos los valores de la matriz.
     *
     * @param matrix matriz de entrada
     * @return total acumulado
     */
    public int sum(int[][] matrix) {
        int total = 0;
        for (int[] row : matrix) {
            for (int cell : row) {
                total += cell;
            }
        }
        return total;
    }

    /**
     * Calcula la diagonal principal.
     *
     * @param matrix matriz cuadrada
     * @return suma diagonal
     */
    public int diagonalSum(int[][] matrix) {
        int total = 0;
        for (int i = 0; i < matrix.length; i++) {
            total += matrix[i][i];
        }
        return total;
    }
}` ,
    challenges: [
      { id: "M1", title: "Mapa térmico", chip: "Matrix", input: "Ingresa valores por fila y columna.", process: "Agrega cada celda a un tablero.", output: "Muestra el mapa operacional consolidado." },
      { id: "M2", title: "Control de asientos", chip: "Matrix", input: "Recibe una matriz de disponibilidad.", process: "Verifica celdas libres y ocupadas.", output: "Entrega el estado de cada asiento." },
      { id: "M3", title: "Ruta de almacén", chip: "Matrix", input: "Carga coordenadas de ubicación.", process: "Calcula accesos por fila y columna.", output: "Entrega la posición exacta del recurso." },
      { id: "M4", title: "Balance de turnos", chip: "Matrix", input: "Registra turnos en una grilla semanal.", process: "Suma por columnas y por filas.", output: "Publica el balance por equipo." },
      { id: "M5", title: "Radar de incidencia", chip: "Matrix", input: "Ingresa métricas por zona.", process: "Cruza ambos ejes de información.", output: "Entrega el segmento con mayor carga." },
    ],
  },
  {
    id: "lists",
    short: "L1",
    title: "Lists",
    summary: "Cadena dinámica de nodos para escenarios con inserción frecuente, expansión progresiva y enlaces flexibles.",
    focus: ["Heap nodes", "Flexible growth", "Pointer orchestration"],
    specs: [
      ["Insert at head", "O(1)", "O(1)", "Se enlaza un nodo nuevo al inicio."],
      ["Insert at tail", "O(n)", "O(1)", "En lista simple requiere búsqueda del final."],
      ["Search by value", "O(n)", "O(1)", "Se recorre nodo por nodo."],
      ["Delete by value", "O(n)", "O(1)", "Se ajustan enlaces adyacentes."],
    ],
    memory:
      "Cada nodo vive en heap y contiene datos más referencias a otros nodos. La ventaja es la expansión dinámica sin necesidad de una zona contigua. El costo es una menor localidad de memoria y más punteros por operación, lo que impacta el rendimiento frente a un array en recorridos intensivos.",
    code: `package com.logicstructures.lists;

import org.springframework.stereotype.Service;

/**
 * Servicio para administrar una lista enlazada simple de tareas operativas.
 */
@Service
public class LinkedTaskService {

    private Node head;

    /**
     * Inserta un nodo al inicio de la cadena.
     *
     * @param value dato a insertar
     */
    public void addFirst(String value) {
        Node newNode = new Node(value);
        newNode.next = head;
        head = newNode;
    }

    /**
     * Busca un elemento exacto en la estructura.
     *
     * @param value valor objetivo
     * @return true cuando el nodo existe
     */
    public boolean contains(String value) {
        Node current = head;
        while (current != null) {
            if (current.value.equals(value)) {
                return true;
            }
            current = current.next;
        }
        return false;
    }

    private static class Node {
        private final String value;
        private Node next;

        private Node(String value) {
            this.value = value;
        }
    }
}` ,
    challenges: [
      { id: "L1", title: "Registro de incidentes", chip: "List", input: "Recibe un nuevo evento operativo.", process: "Inserta el nodo al inicio del flujo.", output: "Publica el incidente más reciente primero." },
      { id: "L2", title: "Catálogo incremental", chip: "List", input: "Ingresa elementos de inventario.", process: "Enlaza cada nodo al final de la secuencia.", output: "Expande el catálogo sin reestructurar todo." },
      { id: "L3", title: "Depuración de duplicados", chip: "List", input: "Carga una serie de nombres.", process: "Comparte referencia y elimina coincidencias.", output: "Entrega una lista limpia y consistente." },
      { id: "L4", title: "Reasignación de tickets", chip: "List", input: "Entradas de soporte por prioridad.", process: "Reordena enlaces según criticidad.", output: "Muestra el orden operativo actualizado." },
      { id: "L5", title: "Aprobaciones encadenadas", chip: "List", input: "Secuencia de autorizaciones.", process: "Avanza nodo por nodo hasta cierre.", output: "Devuelve el estado final del flujo." },
    ],
  },
  {
    id: "stacks",
    short: "S1",
    title: "Stacks",
    summary: "Control LIFO para reversión de acciones, análisis de expresiones, rastreo de llamadas y rollback funcional.",
    focus: ["LIFO", "Rollback", "Top access"],
    specs: [
      ["Push", "O(1)", "O(1)", "Inserción directa en la cima."],
      ["Pop", "O(1)", "O(1)", "Extracción inmediata del último elemento."],
      ["Peek", "O(1)", "O(1)", "Lectura del elemento superior."],
      ["Search", "O(n)", "O(1)", "El control exige exploración completa."],
    ],
    memory:
      "Una pila puede implementarse sobre heap mediante arrays o nodos enlazados, mientras que el marco de ejecución de llamadas vive en stack nativa. El acceso al elemento superior es inmediato porque el puntero solo cambia en un extremo. Esto la hace ideal para deshacer operaciones y evaluar expresiones en orden inverso.",
    code: `package com.logicstructures.stacks;

import java.util.ArrayDeque;
import java.util.Deque;
import org.springframework.stereotype.Service;

/**
 * Servicio para gestionar una pila de operaciones reversibles.
 */
@Service
public class CommandStackService {

    private final Deque<String> stack = new ArrayDeque<>();

    /**
     * Registra una nueva operación en la cima.
     *
     * @param command operación a apilar
     */
    public void push(String command) {
        stack.push(command);
    }

    /**
     * Ejecuta el rollback de la última operación.
     *
     * @return operación removida
     */
    public String pop() {
        if (stack.isEmpty()) {
            throw new IllegalStateException("Stack is empty");
        }
        return stack.pop();
    }

    /**
     * Consulta la operación activa sin modificar la pila.
     *
     * @return elemento en la cima
     */
    public String peek() {
        return stack.peek();
    }
}` ,
    challenges: [
      { id: "S1", title: "Reversión de logs", chip: "Stack", input: "Recibe entradas de auditoría.", process: "Apila cada evento en orden de llegada.", output: "Entrega el log más reciente en primera posición." },
      { id: "S2", title: "Rollback transaccional", chip: "Stack", input: "Captura cambios pendientes.", process: "Guarda cada acción antes de confirmar.", output: "Permite revertir la última modificación." },
      { id: "S3", title: "Validación de paréntesis", chip: "Stack", input: "Ingresa una expresión técnica.", process: "Apila y desapila símbolos de apertura y cierre.", output: "Indica si la sintaxis es consistente." },
      { id: "S4", title: "Navegación backward", chip: "Stack", input: "Recibe el historial de pantallas.", process: "Lee el estado más reciente primero.", output: "Retorna a la vista anterior." },
      { id: "S5", title: "Pipeline de tareas", chip: "Stack", input: "Carga pasos de ejecución.", process: "Procesa el último paso agregado.", output: "Desencadena la acción en orden inverso." },
    ],
  },
  {
    id: "queues",
    short: "Q1",
    title: "Queues",
    summary: "Gestión FIFO para turnos, colas de atención, pipelines y despacho ordenado de solicitudes.",
    focus: ["FIFO", "Turn management", "Service order"],
    specs: [
      ["Enqueue", "O(1)", "O(1)", "Alta de solicitudes al final de la cola."],
      ["Dequeue", "O(1)", "O(1)", "Salida del primer elemento habilitado."],
      ["Front", "O(1)", "O(1)", "Lectura del próximo turno."],
      ["Search", "O(n)", "O(1)", "Inspección secuencial de elementos."],
    ],
    memory:
      "La cola normalmente se implementa sobre heap usando referencias al frente y al final. Esto evita mover todos los elementos después de cada extracción. El patrón FIFO protege el orden de llegada y resulta ideal para atención de usuarios, colas de mensajes y orquestación de tareas asíncronas.",
    code: `package com.logicstructures.queues;

import java.util.ArrayDeque;
import java.util.Queue;
import org.springframework.stereotype.Service;

/**
 * Servicio orientado a la gestión de turnos y solicitudes en orden FIFO.
 */
@Service
public class TicketQueueService {

    private final Queue<String> queue = new ArrayDeque<>();

    /**
     * Inserta un ticket al final de la cola.
     *
     * @param ticket identificador del turno
     */
    public void enqueue(String ticket) {
        queue.offer(ticket);
    }

    /**
     * Retira el siguiente ticket disponible.
     *
     * @return ticket procesado
     */
    public String dequeue() {
        return queue.poll();
    }

    /**
     * Obtiene el ticket que será atendido a continuación.
     *
     * @return elemento frontal
     */
    public String front() {
        return queue.peek();
    }
}` ,
    challenges: [
      { id: "Q1", title: "Turnos de banco", chip: "Queue", input: "Registra clientes en llegada real.", process: "Ubica cada turno al final del flujo.", output: "Atiende primero al cliente más antiguo." },
      { id: "Q2", title: "Despacho de órdenes", chip: "Queue", input: "Recibe órdenes de servicio.", process: "Encola cada solicitud en recepción.", output: "Expide la orden por prioridad temporal." },
      { id: "Q3", title: "Mensajería interna", chip: "Queue", input: "Ingresa notificaciones del sistema.", process: "Conserva el orden exacto de llegada.", output: "Entrega el mensaje más antiguo primero." },
      { id: "Q4", title: "Soporte por tickets", chip: "Queue", input: "Captura tickets abiertos.", process: "Serializa la atención sin saltos.", output: "Muestra el ticket pendiente de resolución." },
      { id: "Q5", title: "Buffer de impresión", chip: "Queue", input: "Carga documentos en espera.", process: "Procesa el primer documento en cola.", output: "Imprime respetando el orden de envío." },
    ],
  },
  {
    id: "integration",
    short: "I6",
    title: "Integration",
    summary: "Orquestación híbrida de arrays, matrices, listas, pilas y colas para resolver flujos corporativos de extremo a extremo.",
    focus: ["Hybrid flow", "Composite design", "Operational orchestration"],
    specs: [
      ["Coordination", "O(n)", "O(n)", "Depende de la combinación de estructuras."],
      ["Lookup chain", "O(n)", "O(1)", "El costo suma cada etapa del pipeline."],
      ["State rollback", "O(1)", "O(1)", "La pila habilita reversión inmediata."],
      ["Dispatch queue", "O(1)", "O(1)", "La cola ordena la ejecución del pipeline."],
    ],
    memory:
      "La integración combina estructuras residentes en heap con referencias cruzadas entre servicios. El patrón clave es aislar responsabilidades: arrays para lotes rápidos, matrices para tableros, listas para crecimiento dinámico, pilas para reversión y colas para secuenciación. La solución gana trazabilidad cuando cada componente conserva una única responsabilidad.",
    code: `package com.logicstructures.integration;

import java.util.List;
import org.springframework.stereotype.Service;

/**
 * Orquestador de datos para combinar múltiples estructuras en un flujo único.
 */
@Service
public class HybridProcessingService {

    /**
     * Calcula la suma global de una secuencia de lotes.
     *
     * @param batches bloques de datos
     * @return total consolidado
     */
    public int consolidate(List<int[]> batches) {
        int total = 0;
        for (int[] batch : batches) {
            for (int value : batch) {
                total += value;
            }
        }
        return total;
    }

    /**
     * Construye un indicador textual para monitoreo.
     *
     * @param arraySize tamaño del lote lineal
     * @param queueSize tamaño de la cola de ejecución
     * @return resumen técnico
     */
    public String buildStatus(int arraySize, int queueSize) {
        return "Array size=" + arraySize + " | Queue size=" + queueSize;
    }
}` ,
    challenges: [
      { id: "I1", title: "Consola unificada", chip: "Hybrid", input: "Recibe lotes, turnos y flags de control.", process: "Distribuye cada dato en la estructura adecuada.", output: "Publica un panel con trazabilidad completa." },
      { id: "I2", title: "Monitoreo de tablero", chip: "Hybrid", input: "Ingresa métricas de filas y colas.", process: "Cruza la matriz con la prioridad de atención.", output: "Entrega una vista operacional consolidada." },
      { id: "I3", title: "Respuesta reversible", chip: "Hybrid", input: "Carga acciones críticas.", process: "Apila cada paso y encola la ejecución.", output: "Permite revertir y continuar sin pérdida." },
      { id: "I4", title: "Gestión de buffers", chip: "Hybrid", input: "Recibe lotes, estados y secuencias.", process: "Asigna arrays para captura y listas para expansión.", output: "Muestra el flujo más eficiente disponible." },
      { id: "I5", title: "Motor de despacho", chip: "Hybrid", input: "Entra una combinación de solicitudes.", process: "Ordena por cola, verifica con pila y consolida con array.", output: "Genera la respuesta final del sistema." },
    ],
  }
];

const nav = document.getElementById("topicNav");
const topicMeta = document.getElementById("topicMeta");
const topicTitle = document.getElementById("topicTitle");
const topicSummary = document.getElementById("topicSummary");
const complexityBody = document.getElementById("complexityBody");
const memoryNote = document.getElementById("memoryNote");
const codeBlock = document.getElementById("codeBlock");
const challengesGrid = document.getElementById("challengesGrid");

function metaCards(topic) {
  return `
    <div class="meta-card fade-in">
      <p class="label">Primary focus</p>
      <p class="value">${topic.title}</p>
      <p class="desc">${topic.summary}</p>
    </div>
    <div class="meta-card fade-in">
      <p class="label">Technical profile</p>
      <p class="value">${topic.focus[0]}</p>
      <p class="desc">${topic.focus[1]} · ${topic.focus[2]}</p>
    </div>
    <div class="meta-card fade-in">
      <p class="label">Runtime behavior</p>
      <p class="value">Predictable</p>
      <p class="desc">Operations designed for deterministic traversal and clear memory boundaries.</p>
    </div>
    <div class="meta-card fade-in">
      <p class="label">Implementation style</p>
      <p class="value">Spring Boot</p>
      <p class="desc">Java service blocks with Javadoc commentary and single-responsibility intent.</p>
    </div>
  `;
}

function renderNav(activeId) {
  nav.innerHTML = topics.map(topic => `
    <button class="nav-item ${topic.id === activeId ? "active" : ""}" data-topic="${topic.id}">
      <strong>${topic.title}</strong>
      <span>${topic.short}</span>
    </button>
  `).join("");

  nav.querySelectorAll("[data-topic]").forEach(btn => {
    btn.addEventListener("click", () => renderTopic(btn.dataset.topic));
  });
}

function renderTopic(id) {
  const topic = topics.find(t => t.id === id) || topics[0];
  document.title = `LOGIC-STRUCTURES V.2026 · ${topic.title}`;
  renderNav(topic.id);

  topicMeta.innerHTML = metaCards(topic);
  topicTitle.textContent = topic.title;
  topicSummary.textContent = topic.summary;
  complexityBody.innerHTML = topic.specs.map(([op, time, space, notes]) => `
    <tr>
      <td>${op}</td>
      <td>${time}</td>
      <td>${space}</td>
      <td>${notes}</td>
    </tr>
  `).join("");
  memoryNote.textContent = topic.memory;
  codeBlock.textContent = topic.code.trim();

  challengesGrid.innerHTML = topic.challenges.map(card => `
    <article class="challenge-card fade-in">
      <div class="challenge-head">
        <strong>${card.id} · ${card.title}</strong>
        <span class="challenge-chip">${card.chip}</span>
      </div>
      <div class="flow">
        <div class="flow-step">
          <span>Entrada de Usuario</span>
          <p>${card.input}</p>
        </div>
        <div class="flow-step">
          <span>Lógica del Proceso</span>
          <p>${card.process}</p>
        </div>
        <div class="flow-step">
          <span>Salida Esperada</span>
          <p>${card.output}</p>
        </div>
      </div>
    </article>
  `).join("");
}

renderTopic("arrays");
